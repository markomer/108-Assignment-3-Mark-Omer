from mock_data import catalog


def lower_than(price):
    # print how many product exist 
    # with a price lower that price var
    pass


def greater_than(price):



lower_than(10)
lower_than(30)
lower_than(50)
lower_than(100)

greater_than(10)
greater_than(30)
greater_than(50)
greater_than(100)

# see test1.py